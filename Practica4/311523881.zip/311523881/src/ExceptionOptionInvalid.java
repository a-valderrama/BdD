/**
 * Excepción para cuando se escoge una opcion invalida
 */
public class ExceptionOptionInvalid extends Exception {}

