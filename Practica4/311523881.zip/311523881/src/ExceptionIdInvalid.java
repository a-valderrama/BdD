/**
 * Excepción para cuando el id es invalido.
 */
public class ExceptionIdInvalid extends Exception {}