Nombre: Ernesto Cardenas Torres | 306155406
Nombre: Alejandro Tonatiuh Valderrama Silva | 311523881
-----------
Es esta practica no hay codigo. El cogido que aparece en el src, junto con los ejecutables del target, son el resultado de la practica2. Para conocer mas al respecto debe verse el readme de dicha practica.
Cabe mecionar, que la practica2 fue individual, por lo que el codigo de cada integrante es distinto. Acordamos enviar el codigo de uno de los integrantes (de Alejandro), para cumplir con el requerimeinto de que se envie, tambien, archivos de practicas pasadas.
----------
Como no hay codigo, no hay que ejecutar nada. Simplemente hay que tener instalado la aplicacion "DIA" para poder ver el diagrama.
El diagrama esta basado en el modelo: Entidad/Relacion - Extendido.
Justamente el objetivo de este diagrama es "mejorar" un diagrama que sigue el modelo Entidad/Relacion, para asi lograr un mejor diseño