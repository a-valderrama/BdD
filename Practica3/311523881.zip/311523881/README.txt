No. Cuenta: 311523881
Nombre: Alejandro Tonatiuh Valderrama Silva
-----------
Es esta practica no hay codigo. El cogido que aparece en el src, junto con los ejecutables del target, son el resultado de la practica2. Para conocer mas al respecto debe verse el readme de dicha practica
----------
Como no hay codigo, no hay que ejecutar nada. Simplemente hay que tener instalado la aplicacion "DIA" para poder ver el diagrama.
El diagrama esta basado en el modelo: Entidad/Relacion.