No. Cuenta: 311523881
Nombre: Alejandro Tonatiuh Valderrama Silva
-----------
El programa es muy facil de correr, simplemente hay que correr el main con el comando:
			"javac Practica2.java"
Dicho comando nos generara los ejecutables de todas las clases (archivos).
Pero para correr el programa basta con ejecutar el comando:
			"java Practica2"
Posteriormente el programa nos indica/pregunta lo que queremos hacer, por lo que es bastante sencillo de usar. En el directorio nos creara los archivos solicitados: "dueños.csv" y "propiedades.csv"
----------
Detalles sobre el programa:
-En los archivos, las filas vacias, es decir, saltos de linea representan valores (entidades) nulas. Lo cual puede, muy seguramente, traer problemas al funcionamiento del programa.
-Se pueden agregar propiedades sin dueño, ya que es posible que aun no se haya vendido esa propiedad.
-La direccion ingresada en el programa debe ser ESTRICTAMENTE separada, un elemento de otro, por el simbolo '.'